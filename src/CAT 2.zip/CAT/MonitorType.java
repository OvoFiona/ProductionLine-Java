
package CAT;

public enum MonitorType {
    LCD,
    LED,
    Type,
}
