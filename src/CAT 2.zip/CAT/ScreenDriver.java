
package CAT;

public class ScreenDriver {

    public static void main(String[] args) {
        Screen screen1 = new Screen("2800x1080", 60, 5);
        Screen screen2 = new Screen("2800x1080", 60, 5);
        System.out.println(screen1);
        System.out.println(screen2);
    }
 }
    
