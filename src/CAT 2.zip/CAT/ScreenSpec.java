
package CAT;

public interface ScreenSpec {
    public String getResolution();
    public int getRefreshRate();
    int getResponseTime();

}
