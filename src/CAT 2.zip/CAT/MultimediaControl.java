
package CAT;

public interface MultimediaControl {
    void play();
    void stop();
    void previous();
    void next();

}
